package com.example.booking.producer;

import com.example.booking.model.BookingEvent;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

@Service
public class BookingProducer {

    @Autowired
    private KafkaTemplate<String, Object> kafkaTemplate;

    public void sendBookingEvent(BookingEvent event) {
        kafkaTemplate.send("booking-topic", event);
        System.out.println("📤 Sent event to Kafka topic 'booking-topic': " + event);
    }
}
