package com.example.booking.controller;

import com.example.booking.model.BookingEvent;
import com.example.booking.producer.BookingProducer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/bookings")   // 👈  base path
public class BookingController {

    @Autowired
    private BookingProducer bookingProducer;

    @PostMapping("/confirm")    // 👈  POST endpoint
    public String confirmBooking(@RequestBody BookingEvent bookingEvent) {
        bookingProducer.sendBookingEvent(bookingEvent);
        return "Booking confirmed and event sent!";
    }
}
