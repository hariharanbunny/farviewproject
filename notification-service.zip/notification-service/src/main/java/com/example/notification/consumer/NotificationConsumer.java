package com.example.notification.consumer;

import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

@Service
public class NotificationConsumer {

    @KafkaListener(topics = "booking-topic", groupId = "notification-group")
    public void consumeMessage(String message) {
        System.out.println("📩 Received booking event from Kafka: " + message);
        System.out.println("📨 Sending email notification for: " + message);
    }
}
