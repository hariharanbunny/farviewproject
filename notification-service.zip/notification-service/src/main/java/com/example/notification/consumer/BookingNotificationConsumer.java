package com.example.notification.consumer;

import com.example.notification.model.BookingEvent;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

@Service
public class BookingNotificationConsumer {

    private final ObjectMapper objectMapper = new ObjectMapper();

    @KafkaListener(topics = "booking-topic", groupId = "notification-group")
    public void consume(String message) throws Exception {
        System.out.println("📩 Received message from Kafka: " + message);
        try {
            // Deserialize the JSON message
            BookingEvent event = objectMapper.readValue(message, BookingEvent.class);

            // Simulate error for testing retry/DLT
            if ("FAIL".equalsIgnoreCase(event.getStatus())) {
                throw new RuntimeException("Simulated failure for retry testing");
            }

            // Normal flow
            System.out.println("✅ Notification sent to: " + event.getCustomerName());

        } catch (Exception e) {
            System.err.println("❌ Error processing message: " + message);
            throw e; // rethrow to trigger retry/DLT mechanism
        }
    }
}
